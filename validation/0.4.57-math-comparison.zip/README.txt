Offer Filter math differential probe

Baseline repository: Dillxn/dasher-offer-filter
Baseline commit: 98d410ceb29341928d7605d464ac4aee051ecf39
Candidate: saved uncommitted shared-floor/pay-item implementation snapshot taken during the 0.4.57 gate.
This compares the scoring implementation with item disabled; it does not test Android adapters or parsing.

Original result: 2,500 deterministic scenarios; 15,000 compared records; zero mismatches.
Seed: 20261003L. Each scenario emits strict and area standalone decisions, strict and area add-on decisions,
old-axis floor/score/reaches/required-pay values, and declined-learning summary.
Inputs include null and zero route values, fractional mileage, extreme distances, learned on/off, hotspot
values, and scales 1/33/97/100/125/200. No new optional test run was performed when this evidence was packaged.

before/ and after/ each contain the six exact math/model Java sources used, MathProbe.java, and minimal
DecisionLog/AddOnOffer stubs. The stubs isolate math from Android logging and add-on parsing; they are the
same in both snapshots. results.txt contains the original output for that snapshot.

Reproduce with Java 17:
  python3 reproduce.py --java-home /path/to/jdk17
The runner compiles into a temporary directory, compares both outputs, and verifies they equal the saved
original outputs. It does not need Gradle, Android SDK, network access, or a repository checkout.

SHA256SUMS.json hashes all source, runner, README and original output files. Existing compiled .class files
are intentionally excluded from the portable evidence archive.
