package com.local.dasherfilter;
import java.util.Random;
public class MathProbe {
 static final Random r=new Random(20261003L);
 static int floor(int n){return r.nextInt(4)==0?0:r.nextInt(n);}
 static Integer number(int n){int k=r.nextInt(12);return k==0?null:k==1?0:r.nextInt(n);}
 static Double distance(){int k=r.nextInt(16);return k==0?null:k==1?0.0:k==2?1e18:k==3?1e-12:1.0301+r.nextInt(500)/10.0;}
 static String decision(OfferRule.Decision d){return d.result+"|"+d.requiredCents+"|"+d.reason+"|"+d.scorePercent+"|"+d.minimumScalePercent;}
 public static void main(String[] args){
  for(int i=0;i<2500;i++){
   AcceptedBest best=new AcceptedBest(floor(5000),1+r.nextInt(100),floor(5000),0.1+r.nextInt(200)/10.0,floor(5000),1+r.nextInt(8));
   DeclinedFloor declined=new DeclinedFloor(floor(5000),new AcceptedBest(floor(5000),1+r.nextInt(100),floor(5000),0.1+r.nextInt(200)/10.0,floor(5000),1+r.nextInt(8)));
   int scale=new int[]{1,33,97,100,125,200}[r.nextInt(6)];
   FilterSettings rules=new FilterSettings(true,floor(3000),floor(500),floor(100),floor(1000),floor(6),r.nextBoolean(),floor(5000),best,declined)
       .withHotspotProximity(floor(300)).withMinimumScalePercent(scale);
   OfferSnapshot offer=new OfferSnapshot(number(5000),distance(),number(90),number(8),number(6000),distance());
   OfferSnapshot added=new OfferSnapshot(number(1000),distance(),number(25),number(3));
   AddOnOffer addon=new AddOnOffer(offer,added,offer);
   for(boolean area:new boolean[]{false,true}){
    FilterSettings mode=rules.withScoreByArea(area);
    System.out.println(i+"/"+area+"/offer:"+decision(OfferRule.evaluate(offer,mode)));
    System.out.println(i+"/"+area+"/addon:"+decision(OfferRule.evaluateAddOn(addon,mode)));
   }
   AreaScore.Floors f=AreaScore.floors(rules,offer);
   long pay=offer.payCents==null?0:offer.payCents;
   String costs="";
   for(int a=0;a<5;a++)costs+="/"+f.active[a]+":"+(f.cents[a]==null?"?":f.cents[a].stripTrailingZeros().toPlainString());
   System.out.println(i+"/floors:"+costs+"|"+AreaScore.score(f,pay)+"|"+AreaScore.reaches(f,pay,scale)+"|"+AreaScore.requiredPay(f,scale));
   System.out.println(i+"/learn:"+DeclinedFloor.raisedBy(rules,offer).summary());
  }
 }
}