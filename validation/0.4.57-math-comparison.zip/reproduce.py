#!/usr/bin/env python3
"""Recompile the saved before/after math snapshots and compare all deterministic records.
Requires Java 17. No Android SDK, Gradle, network or repository checkout needed.
"""
import argparse
from pathlib import Path
import os
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--java-home', default=os.environ.get('JAVA_HOME'))
args = parser.parse_args()
base = Path(__file__).resolve().parent
javac = str(Path(args.java_home) / 'bin/javac') if args.java_home else shutil.which('javac')
java = str(Path(args.java_home) / 'bin/java') if args.java_home else shutil.which('java')
if not javac or not java:
    parser.error('Java 17 is required; set JAVA_HOME or pass --java-home')
results = {}
with tempfile.TemporaryDirectory(prefix='offer-math-reproduction-') as temp:
    for variant in ('before', 'after'):
        classes = Path(temp) / variant
        classes.mkdir()
        subprocess.run([javac, '-d', str(classes), *map(str, sorted((base / variant).glob('*.java')))], check=True)
        run = subprocess.run([java, '-Xmx256m', '-cp', str(classes), 'com.local.dasherfilter.MathProbe'],
                             check=True, capture_output=True, text=True)
        results[variant] = run.stdout.splitlines()
        recorded = (base / variant / 'results.txt').read_text().splitlines()
        if results[variant] != recorded:
            raise SystemExit(f'{variant}: output differs from the saved original run')
    before, after = results['before'], results['after']
    mismatches = sum(a != b for a, b in zip(before, after)) + abs(len(before) - len(after))
    print(f'before={len(before)} after={len(after)} mismatches={mismatches}')
    if mismatches or len(before) != 15000:
        raise SystemExit(1)
